<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/*
File ini digunakan untuk konfigurasi dasar pada aplikasi 
Seperti database, encrypt key, dan lainnya
*/

define('KEY_MAPBOXAPI', 'isikan_mapboxapi_key_anda_disini');
define('KEY_RAPIDAPI', 'isikan_rapidapi_key_anda_disini');