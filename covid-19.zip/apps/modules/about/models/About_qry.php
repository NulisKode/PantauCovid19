<?php

/*
 * ***************************************************************
 *  Script : 
 *  Version : 
 *  Date :
 *  Author : PAW! Development Semarang
 *  Email : pawdev.id@gmail.com
 *  Description : 
 * ***************************************************************
 */

/**
 * Description of About_qry
 *
 * @author adi
 */
class About_qry extends CI_Model {

    protected $data = array();

    //put your code here
    public function __construct() {
        parent::__construct();
    }
    
}
