<?php

/*
 * ***************************************************************
 *  Script : 
 *  Version : 
 *  Date :
 *  Author : PAW! Development Semarang
 *  Email : pawdev.id@gmail.com
 *  Description : 
 * ***************************************************************
 */

/**
 * Description of Wilayah_qry
 *
 * @author adi
 */
class Wilayah_qry extends CI_Model {

    protected $data = array();

    //put your code here
    public function __construct() {
        parent::__construct();
    }
    
}
