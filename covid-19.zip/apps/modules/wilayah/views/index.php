<div class="row w-100">
    <div class="col-lg-4 mx-auto">
        <div class="auth-form-transparent text-left p-5 text-center">
            <img src="<?= base_url('kapella/images/logo.jpg'); ?>" class="lock-profile-img" alt="img">
            <form class="pt-5">
                <div class="mt-5">
                    <a class="btn btn-block btn-danger btn-lg font-weight-medium text-white" href="<?=site_url('home');?>">
                        Home
                    </a>
                </div>
                <div class="mt-3 text-center">
                    <h2 class="text-white">Halaman belum tersedia, silahkan kembali ke beranda</h2>
                </div>
            </form>
        </div>
    </div>
</div>